(function(){
    function Start({
        console.log("application Started")

    })

    window.addEventListener("load" Start)

})