# WebandScriptProgrammingLK
Live Host = [https://my-portfolio-8qop.onrender.com](https://my-portfolio-8qop.onrender.com)

ALL CODE WAS DONE BY MYSELF

NO COPPIES OF OTHERS DESEIGNS AND OR CODE
THANK YOU
