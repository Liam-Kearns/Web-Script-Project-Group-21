//calls DB from Mongoose
module.exports = {"URI":"mongodb+srv://liamkearns:Liampro9@mongodbserver.nehb4oa.mongodb.net/Assignments"}

